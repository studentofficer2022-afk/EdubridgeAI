import { GoogleGenAI, Type } from "@google/genai";

const apiKey = (import.meta.env?.VITE_GEMINI_API_KEY) || (process.env.GEMINI_API_KEY) || "";
const ai = new GoogleGenAI({ apiKey });

export async function askGemini(prompt: string, systemInstruction?: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: systemInstruction || "You are a helpful education assistant for a university English department. Answer clearly and professionally.",
        temperature: 0.7,
      },
    });
    return response.text || "I'm sorry, I couldn't generate a response.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "⚠️ AI service is currently unavailable. Please check your API key or try again later.";
  }
}

export async function translateText(text: string, direction: "en-my" | "my-en") {
  const prompt = direction === "en-my" 
    ? `Translate the following English text to Burmese: "${text}". Provide the Burmese translation and the phonetic pronunciation.`
    : `Translate the following Burmese text to English: "${text}". Provide the English translation and the phonetic pronunciation.`;
  
  return askGemini(prompt, "You are a professional English-Burmese translator. Provide accurate and natural translations.");
}

export async function generateQuiz(topic: string, count: number, type: string, materialContext?: string) {
  const isInteractive = type === "MCQ" || type === "TF" || type === "Mixed";
  
  if (isInteractive) {
    const prompt = `Generate a quiz with ${count} questions about: ${topic}. 
    Type: ${type}.
    ${materialContext ? `Source material context: ${materialContext}` : ""}
    
    Return the response ONLY as a JSON array of objects with this structure:
    [
      {
        "id": "string",
        "question": "string",
        "options": ["string", "string", "string", "string"], // Only for MCQ
        "correctAnswer": "string", // For MCQ (A, B, C, or D) or TF (True or False)
        "type": "MCQ" | "TF"
      }
    ]`;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          systemInstruction: "You are an expert teacher. Return ONLY valid JSON.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctAnswer: { type: Type.STRING },
                type: { type: Type.STRING }
              },
              required: ["id", "question", "correctAnswer", "type"]
            }
          }
        }
      });
      return response.text;
    } catch (error) {
      console.error("Quiz JSON Error:", error);
      return "[]";
    }
  }

  const typeDescription = type === "Short" ? "short statement-type questions (1-2 sentences)" : 
                          type === "Long" ? "long statement-type questions (paragraph length)" : 
                          type;
  
  const prompt = `Generate a quiz with ${count} ${typeDescription} questions about: ${topic}. 
  ${materialContext ? `IMPORTANT: Use the following study material as the primary source for the quiz questions: ${materialContext}` : "Use general knowledge suitable for university students."}
  Format the output as a clean, readable list. 
  If Short or Long statement type, provide a sample answer or key points for each question.`;
  
  return askGemini(prompt, "You are an expert teacher creating a quiz for university students.");
}

export async function generateNotes(topic: string, format: string, materialContext?: string) {
  const prompt = `Create ${format} on the topic: ${topic}. 
  ${materialContext ? `IMPORTANT: Use the following study material as the primary source for these notes: ${materialContext}` : "Use general academic knowledge suitable for university students."}
  Use clear headings, bullet points, and sub-headings. 
  Make it easy for students to study from.`;
  
  return askGemini(prompt, "You are a senior professor creating study notes for students.");
}
