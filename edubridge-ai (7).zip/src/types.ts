export type Role = "student" | "teacher" | "admin" | null;

export interface Notice {
  id: string;
  title: string;
  text: string;
  priority: "High" | "Medium" | "Normal";
  date: string;
  active: boolean;
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export interface StudyMaterial {
  id: string;
  name: string;
  category: "qual" | "f1" | "f2";
  uploadDate: string;
}

export interface QuizQuestion {
  question: string;
  options?: string[];
  answer: string;
  type: "MCQ" | "TF" | "Short" | "Long";
}

export interface TimetableEntry {
  time: string;
  mon: string;
  tue: string;
  wed: string;
  thu: string;
  fri: string;
}

export interface Photo {
  id: string;
  url: string;
  caption: string;
  date: string;
}

export interface UserAccount {
  id: string;
  fullName: string;
  username: string;
  password: string;
  role: "student" | "teacher" | "admin";
}
