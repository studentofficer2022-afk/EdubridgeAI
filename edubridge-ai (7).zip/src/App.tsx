import React, { useState, useEffect, useRef } from "react";
import { 
  GraduationCap, 
  MessageSquare, 
  BookOpen, 
  Puzzle, 
  Calendar, 
  Bell, 
  LogOut, 
  Plus, 
  Trash2, 
  Send, 
  User, 
  ShieldCheck, 
  ChevronRight,
  FileText,
  Upload,
  BrainCircuit,
  Sparkles,
  Search,
  CheckCircle2,
  AlertCircle,
  Image as ImageIcon,
  Camera,
  Languages,
  Clock,
  MapPin,
  X
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import ReactMarkdown from "react-markdown";
import { jsPDF } from "jspdf";
import { Document, Packer, Paragraph, TextRun } from "docx";
import { saveAs } from "file-saver";
import { 
  collection, 
  addDoc, 
  query, 
  orderBy, 
  onSnapshot, 
  serverTimestamp,
  deleteDoc,
  doc
} from "firebase/firestore";
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { db, storage } from "@/src/lib/firebase";
import { cn } from "@/src/lib/utils";
import { askGemini, generateQuiz, generateNotes, translateText } from "@/src/services/gemini";
import type { Role, Notice, ChatMessage, StudyMaterial, TimetableEntry, Photo, UserAccount } from "@/src/types";
import CampusMap from "@/src/components/CampusMap";

// --- Constants & Mock Data ---
const MOCK_USERS: UserAccount[] = [
  { id: "1", fullName: "Admin User", username: "admin", password: "123", role: "admin" },
  { id: "2", fullName: "Teacher User", username: "teacher", password: "123", role: "teacher" },
  { id: "3", fullName: "Student User", username: "student", password: "123", role: "student" },
];
const MOCK_NOTICES: Notice[] = [
  { id: "1", title: "Mid-Term Exams", text: "Exams start from April 15th. Please check your schedules.", priority: "High", date: "05 Apr 2026", active: true },
  { id: "2", title: "Guest Lecture", text: "Dr. Smith will be speaking on Modern Literature this Friday.", priority: "Medium", date: "04 Apr 2026", active: true },
  { id: "3", title: "Library Hours", text: "Extended library hours for exam preparation: 8 AM - 10 PM.", priority: "Normal", date: "03 Apr 2026", active: true },
];

const MOCK_MATERIALS: StudyMaterial[] = [
  { id: "1", name: "Shakespeare_Hamlet_Themes.pdf", category: "qual", uploadDate: "01 Apr 2026" },
  { id: "2", name: "Grammar_Basics_Part1.pdf", category: "f1", uploadDate: "02 Apr 2026" },
  { id: "3", name: "Modern_Poetry_Anthology.pdf", category: "f2", uploadDate: "03 Apr 2026" },
];

const MOCK_PHOTOS: Photo[] = [
  { id: "1", url: "https://picsum.photos/seed/dept1/800/600", caption: "Annual Literary Fest 2025", date: "15 Mar 2026" },
  { id: "2", url: "https://picsum.photos/seed/dept2/800/600", caption: "Guest Lecture by Dr. Smith", date: "04 Apr 2026" },
  { id: "3", url: "https://picsum.photos/seed/dept3/800/600", caption: "Department Library Study Session", date: "03 Apr 2026" },
];

const TIMETABLE: TimetableEntry[] = [
  { time: "08:00", mon: "English", tue: "History", wed: "English", thu: "Grammar", fri: "Literature" },
  { time: "09:00", mon: "Grammar", tue: "English", wed: "History", thu: "English", fri: "Grammar" },
  { time: "10:30", mon: "Literature", tue: "Grammar", wed: "Literature", thu: "History", fri: "English" },
  { time: "11:30", mon: "History", tue: "Literature", wed: "Grammar", thu: "Literature", fri: "History" },
];

// --- Components ---

const Card = ({ children, className, onClick }: { children: React.ReactNode; className?: string; onClick?: () => void }) => (
  <motion.div 
    whileHover={onClick ? { y: -4, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)" } : {}}
    onClick={onClick}
    className={cn("bg-white rounded-2xl p-6 shadow-sm border border-slate-100 transition-all", className, onClick && "cursor-pointer")}
  >
    {children}
  </motion.div>
);

const Button = ({ children, className, variant = "primary", ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "danger" | "ghost" }) => {
  const variants = {
    primary: "bg-teal-600 text-white hover:bg-teal-700 shadow-teal-100",
    secondary: "bg-slate-100 text-slate-700 hover:bg-slate-200 shadow-slate-50",
    danger: "bg-rose-500 text-white hover:bg-rose-600 shadow-rose-100",
    ghost: "bg-transparent text-slate-600 hover:bg-slate-50 shadow-none",
  };
  return (
    <button 
      className={cn("px-4 py-2 rounded-xl font-medium transition-all active:scale-95 shadow-sm disabled:opacity-50 disabled:pointer-events-none", variants[variant], className)}
      {...props}
    >
      {children}
    </button>
  );
};

const Badge = ({ children, variant = "Normal" }: { children: React.ReactNode; variant?: "High" | "Medium" | "Normal" }) => {
  const variants = {
    High: "bg-rose-100 text-rose-700 border-rose-200",
    Medium: "bg-amber-100 text-amber-700 border-amber-200",
    Normal: "bg-teal-100 text-teal-700 border-teal-200",
  };
  return (
    <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border", variants[variant])}>
      {children}
    </span>
  );
};

// --- Main Application ---

export default function App() {
  const [role, setRole] = useState<Role>(null);
  const [page, setPage] = useState<string>("home");
  const [notices, setNotices] = useState<Notice[]>(MOCK_NOTICES);
  const [materials, setMaterials] = useState<StudyMaterial[]>(MOCK_MATERIALS);
  const [timetable, setTimetable] = useState<TimetableEntry[]>(TIMETABLE);
  const [timetableImage, setTimetableImage] = useState<string | null>(null);
  const [photos, setPhotos] = useState<Photo[]>(MOCK_PHOTOS);
  const [users, setUsers] = useState<UserAccount[]>(MOCK_USERS);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [quizResult, setQuizResult] = useState("");
  const [quizQuestions, setQuizQuestions] = useState<any[]>([]);
  const [currentQuizIndex, setCurrentQuizIndex] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, string>>({});
  const [quizScore, setQuizScore] = useState<number | null>(null);
  const [quizzesAttempted, setQuizzesAttempted] = useState(0);
  
  const [dictionaryInput, setDictionaryInput] = useState("");
  const [dictionaryResult, setDictionaryResult] = useState("");
  const [dictionaryDirection, setDictionaryDirection] = useState<"en-my" | "my-en">("en-my");

  const [quizYear, setQuizYear] = useState<"qual" | "f1" | "f2" | "all">("all");
  const [quizMaterialId, setQuizMaterialId] = useState<string>("none");
  const [quizSource, setQuizSource] = useState<"ai" | "material">("ai");
  const [notesSource, setNotesSource] = useState<"ai" | "material">("ai");
  const [notesYear, setNotesYear] = useState<"qual" | "f1" | "f2" | "all">("all");
  const [notesMaterialId, setNotesMaterialId] = useState<string>("none");
  const [notesResult, setNotesResult] = useState("");
  const [messages, setMessages] = useState<any[]>([]);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [showNotification, setShowNotification] = useState(false);
  const [latestNotice, setLatestNotice] = useState<Notice | null>(null);
  const prevNoticesLength = useRef(notices.length);

  useEffect(() => {
    if (notices.length > prevNoticesLength.current) {
      const newest = notices[0];
      setLatestNotice(newest);
      setShowNotification(true);
      // Auto-hide after 8 seconds
      const timer = setTimeout(() => setShowNotification(false), 8000);
      return () => clearTimeout(timer);
    }
    prevNoticesLength.current = notices.length;
  }, [notices]);

  useEffect(() => {
    const q = query(collection(db, "messages"), orderBy("timestamp", "asc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMessages(msgs);
    });
    return () => unsubscribe();
  }, []);

  const handleSendMessage = async (text: string, file?: File) => {
    if (!currentUser) return;
    
    let fileData = {};
    if (file) {
      if (file.size > 50 * 1024 * 1024) {
        alert("File size exceeds 50MB limit.");
        return;
      }
      
      const storageRef = ref(storage, `chat/${Date.now()}_${file.name}`);
      const uploadTask = uploadBytesResumable(storageRef, file);
      
      await new Promise((resolve, reject) => {
        uploadTask.on('state_changed', 
          (snapshot) => {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            setUploadProgress(progress);
          }, 
          (error) => reject(error), 
          async () => {
            const url = await getDownloadURL(uploadTask.snapshot.ref);
            fileData = {
              fileUrl: url,
              fileName: file.name,
              fileType: file.type,
              fileSize: file.size
            };
            setUploadProgress(null);
            resolve(null);
          }
        );
      });
    }

    if (!text && !file) return;

    await addDoc(collection(db, "messages"), {
      senderId: currentUser.id,
      senderName: currentUser.fullName,
      senderRole: currentUser.role,
      content: text,
      timestamp: serverTimestamp(),
      ...fileData
    });
    setInput("");
  };

  const handleDeleteMessage = async (id: string) => {
    if (confirm("Delete this message?")) {
      await deleteDoc(doc(db, "messages", id));
    }
  };

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory]);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  const handleLogin = (selectedRole: Role) => {
    const user = users.find(u => u.username === username && u.password === password && u.role === selectedRole);

    if (user) {
      setRole(selectedRole);
      setCurrentUser(user);
      setPage("home");
      setLoginError("");
    } else {
      setLoginError(`Invalid ${selectedRole} credentials.`);
    }
  };

  const handleLogout = () => {
    setRole(null);
    setCurrentUser(null);
    setPage("home");
    setChatHistory([]);
    setUsername("");
    setPassword("");
  };

  const handleSendAIChat = async () => {
    if (!input.trim() || isLoading) return;
    const userMsg = input.trim();
    setInput("");
    setChatHistory(prev => [...prev, { role: "user", content: userMsg }]);
    setIsLoading(true);

    // Pass the list of materials to the AI as context
    const materialNames = materials.map(m => m.name).join(", ");
    const response = await askGemini(userMsg, `You are a helpful education assistant for a university English department. 
    The following study materials are available in the department: ${materialNames}.
    IMPORTANT: 
    1. If the user's query is about the available materials or topics covered in them, answer directly.
    2. If the query is completely unrelated to the English department or the available materials, start your response with: "This answer is provided by AI (Out of Scope of Study Material):" followed by the answer.
    3. Be professional and academic.`);
    
    setChatHistory(prev => [...prev, { role: "assistant", content: response }]);
    setIsLoading(false);
  };

  const handleGenerateQuiz = async (topic: string, count: number, type: string) => {
    setIsLoading(true);
    let materialContext = "";
    if (quizSource === "material" && quizMaterialId !== "none") {
      const selectedMaterial = materials.find(m => m.id === quizMaterialId);
      if (selectedMaterial) {
        materialContext = `Topic: ${selectedMaterial.name}. Year: ${selectedMaterial.category.toUpperCase()}.`;
      }
    } else if (quizSource === "material" && quizYear !== "all") {
      const yearMaterials = materials.filter(m => m.category === quizYear);
      if (yearMaterials.length > 0) {
        materialContext = `Topics from ${quizYear.toUpperCase()} materials: ${yearMaterials.map(m => m.name).join(", ")}.`;
      }
    }

    const result = await generateQuiz(topic, count, type, materialContext);
    
    if (type === "MCQ" || type === "TF" || type === "Mixed") {
      try {
        const questions = JSON.parse(result);
        setQuizQuestions(questions);
        setQuizResult("");
        setCurrentQuizIndex(0);
        setQuizAnswers({});
        setQuizScore(null);
      } catch (e) {
        console.error("Failed to parse quiz JSON", e);
        setQuizResult(result);
      }
    } else {
      setQuizResult(result);
      setQuizQuestions([]);
    }
    setIsLoading(false);
  };

  const handleQuizSubmit = () => {
    let score = 0;
    quizQuestions.forEach(q => {
      if (quizAnswers[q.id] === q.correctAnswer) {
        score++;
      }
    });
    setQuizScore(score);
    setQuizzesAttempted(prev => prev + 1);
  };

  const handleTranslate = async () => {
    if (!dictionaryInput.trim()) return;
    setIsLoading(true);
    const result = await translateText(dictionaryInput, dictionaryDirection);
    setDictionaryResult(result);
    setIsLoading(false);
  };

  const handleGenerateNotes = async (topic: string, format: string) => {
    setIsLoading(true);
    let materialContext = "";
    if (notesSource === "material" && notesMaterialId !== "none") {
      const selectedMaterial = materials.find(m => m.id === notesMaterialId);
      if (selectedMaterial) {
        materialContext = `Topic: ${selectedMaterial.name}. Year: ${selectedMaterial.category.toUpperCase()}.`;
      }
    } else if (notesSource === "material" && notesYear !== "all") {
      const yearMaterials = materials.filter(m => m.category === notesYear);
      if (yearMaterials.length > 0) {
        materialContext = `Topics from ${notesYear.toUpperCase()} materials: ${yearMaterials.map(m => m.name).join(", ")}.`;
      }
    }

    const result = await generateNotes(topic, format, materialContext);
    setNotesResult(result);
    setIsLoading(false);
  };

  const handleDownloadPDF = () => {
    if (!notesResult) return;
    const doc = new jsPDF();
    const splitText = doc.splitTextToSize(notesResult, 180);
    doc.text(splitText, 15, 15);
    doc.save("EduBridge_Notes.pdf");
  };

  const handleDownloadDOCX = async () => {
    if (!notesResult) return;
    const doc = new Document({
      sections: [{
        properties: {},
        children: notesResult.split("\n").map(line => new Paragraph({
          children: [new TextRun(line)],
        })),
      }],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, "EduBridge_Notes.docx");
  };

  const [showNoticeForm, setShowNoticeForm] = useState(false);
  const [newNoticeTitle, setNewNoticeTitle] = useState("");
  const [newNoticeText, setNewNoticeText] = useState("");
  const [newNoticePriority, setNewNoticePriority] = useState<"High" | "Medium" | "Normal">("Normal");

  const handleAddNotice = (title: string, text: string, priority: "High" | "Medium" | "Normal") => {
    const newNotice: Notice = {
      id: Math.random().toString(36).substr(2, 9),
      title,
      text,
      priority,
      date: new Date().toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
      active: true
    };
    setNotices(prev => [newNotice, ...prev]);
  };

  const handleDeleteNotice = (id: string) => {
    setNotices(prev => prev.filter(n => n.id !== id));
  };

  const [searchQuery, setSearchQuery] = useState("");

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>, category: "qual" | "f1" | "f2") => {
    const file = e.target.files?.[0];
    if (!file) return;

    const newMaterial: StudyMaterial = {
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      category: category,
      uploadDate: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
    };

    setMaterials(prev => [newMaterial, ...prev]);
    // In a real app, we would upload the file to a server here
    alert(`Successfully "uploaded" ${file.name} to ${category.toUpperCase()}!`);
  };

  const handleDeleteMaterial = (id: string) => {
    setMaterials(prev => prev.filter(m => m.id !== id));
  };

  const handleAddTimetableRow = () => {
    setTimetable(prev => [...prev, { time: "00:00", mon: "", tue: "", wed: "", thu: "", fri: "" }]);
  };

  const handleTimetableImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTimetableImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const newPhoto: Photo = {
          id: Math.random().toString(36).substr(2, 9),
          url: reader.result as string,
          caption: "New Activity Photo",
          date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
        };
        setPhotos(prev => [newPhoto, ...prev]);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeletePhoto = (id: string) => {
    setPhotos(prev => prev.filter(p => p.id !== id));
  };

  const filteredMaterials = materials.filter(m => 
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!role) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8 border border-slate-100"
        >
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-teal-200">
              <GraduationCap className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-slate-800 mb-1">EduBridge AI</h1>
            <p className="text-sm text-slate-500">English Department · DSA Initiative</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Username</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Username"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Password</label>
              <div className="relative">
                <ShieldCheck className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 transition-all"
                />
              </div>
            </div>

            {loginError && (
              <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl flex items-center gap-2 text-rose-600 text-xs font-medium">
                <AlertCircle className="w-4 h-4" />
                {loginError}
              </div>
            )}

            <div className="pt-4 grid grid-cols-3 gap-3">
              <Button onClick={() => handleLogin("student")} className="py-4 flex flex-col items-center gap-1 h-auto">
                <span className="text-lg">🎒</span>
                <span className="text-xs">Student</span>
              </Button>
              <Button onClick={() => handleLogin("teacher")} variant="secondary" className="py-4 flex flex-col items-center gap-1 h-auto border-2 border-slate-100 hover:border-teal-500">
                <span className="text-lg">👩‍🏫</span>
                <span className="text-xs">Teacher</span>
              </Button>
              <Button onClick={() => handleLogin("admin")} variant="secondary" className="py-4 flex flex-col items-center gap-1 h-auto border-2 border-slate-100 hover:border-indigo-500">
                <span className="text-lg">⚙️</span>
                <span className="text-xs">Admin</span>
              </Button>
            </div>
          </div>

          <div className="mt-8 text-center">
            <p className="text-[10px] text-slate-400 font-medium">Conceptualized and designed by Sya Ashok Bhardwaj for Students of DSA</p>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-white border-r border-slate-200 flex flex-col sticky top-0 h-auto md:h-screen z-20">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-teal-600 rounded-xl flex items-center justify-center shadow-lg shadow-teal-100">
            <GraduationCap className="w-6 h-6 text-white" />
          </div>
          <span className="font-bold text-xl text-slate-800">EduBridge</span>
        </div>

        <nav className="flex-1 px-4 py-2 space-y-1 overflow-y-auto">
          {[
            { id: "home", label: "Dashboard", icon: Calendar },
            { id: "tutor", label: "AI Tutor", icon: BrainCircuit },
            { id: "materials", label: "Materials", icon: BookOpen },
            { id: "quiz", label: "Quizzes", icon: Puzzle },
            { id: "dictionary", label: "Dictionary", icon: Languages },
            { id: "map", label: "Campus Map", icon: MapPin },
            { id: "photos", label: "Photos", icon: ImageIcon },
            { id: "chat", label: "Group Chat", icon: MessageSquare },
            { id: "notices", label: "Notices", icon: Bell },
            ...(role === "admin" ? [
              { id: "manage-timetable", label: "Timetable", icon: Calendar },
              { id: "manage-users", label: "Users", icon: User }
            ] : []),
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium",
                page === item.id 
                  ? "bg-teal-50 text-teal-700" 
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-700"
              )}
            >
              <item.icon className={cn("w-5 h-5", page === item.id ? "text-teal-600" : "text-slate-400")} />
              {item.label}
            </button>
          ))}
          {role === "teacher" && (
            <button
              onClick={() => setPage("notes")}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium",
                page === "notes" 
                  ? "bg-indigo-50 text-indigo-700" 
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-700"
              )}
            >
              <FileText className={cn("w-5 h-5", page === "notes" ? "text-indigo-600" : "text-slate-400")} />
              Notes Gen
            </button>
          )}
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className="bg-slate-50 rounded-2xl p-4 mb-4">
            <div className="flex items-center gap-3 mb-1">
              <div className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center">
                <User className="w-4 h-4 text-teal-600" />
              </div>
              <span className="font-bold text-sm text-slate-700 capitalize">{role}</span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">English Dept</p>
          </div>
          <Button variant="ghost" className="w-full flex items-center justify-center gap-2" onClick={handleLogout}>
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto relative">
        {/* Real-time Notification Toast */}
        <AnimatePresence>
          {showNotification && latestNotice && (
            <motion.div
              initial={{ opacity: 0, y: -50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.9 }}
              className="fixed top-6 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4"
            >
              <div className="bg-white rounded-2xl shadow-2xl border border-teal-100 p-4 flex items-start gap-4 ring-4 ring-teal-500/10">
                <div className="w-12 h-12 bg-teal-600 rounded-xl flex items-center justify-center shrink-0 shadow-lg shadow-teal-200">
                  <Bell className="w-6 h-6 text-white animate-ring" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-bold text-teal-600 uppercase tracking-widest">New Announcement</span>
                    <button onClick={() => setShowNotification(false)} className="text-slate-400 hover:text-slate-600 transition-colors">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <h4 className="font-bold text-slate-800 truncate">{latestNotice.title}</h4>
                  <p className="text-xs text-slate-500 line-clamp-2 mt-1">{latestNotice.text}</p>
                  <button 
                    onClick={() => {
                      setPage("notices");
                      setShowNotification(false);
                    }}
                    className="mt-3 text-xs font-bold text-teal-600 hover:text-teal-700 flex items-center gap-1"
                  >
                    View Details <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {page === "home" && (
            <motion.div 
              key="home"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h2 className="text-3xl font-bold text-slate-800">Welcome back, {currentUser?.fullName || role}! 👋</h2>
                  <p className="text-slate-500">Here's what's happening in your department today.</p>
                </div>
                <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-2xl border border-slate-100 shadow-sm">
                  <Calendar className="w-4 h-4 text-teal-600" />
                  <span className="text-sm font-semibold text-slate-600">
                    {new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </span>
                  <div className="w-px h-4 bg-slate-200 mx-1" />
                  <Clock className="w-4 h-4 text-teal-600" />
                  <span className="text-sm font-semibold text-slate-600">
                    {new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </header>

              {/* New Notice Alert Banner for Dashboard */}
              {notices.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-indigo-600 rounded-2xl p-4 text-white flex items-center justify-between shadow-lg shadow-indigo-100 overflow-hidden relative"
                >
                  <div className="flex items-center gap-4 relative z-10">
                    <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                      <Bell className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-indigo-100 uppercase tracking-widest mb-0.5">Latest Update</p>
                      <p className="font-bold text-sm line-clamp-1">{notices[0].title}</p>
                    </div>
                  </div>
                  <Button 
                    variant="secondary" 
                    onClick={() => setPage("notices")}
                    className="bg-white text-indigo-600 hover:bg-indigo-50 text-xs py-2 relative z-10"
                  >
                    Read Now
                  </Button>
                  <Sparkles className="absolute right-[-10px] top-[-10px] w-24 h-24 text-white/10" />
                </motion.div>
              )}

              {/* Bento Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="md:col-span-2 bg-gradient-to-br from-teal-600 to-teal-700 text-white border-none overflow-hidden relative group">
                  <div className="relative z-10">
                    <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center mb-6 backdrop-blur-md">
                      <Sparkles className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold mb-2">Ready to study smarter?</h3>
                    <p className="text-teal-50/80 mb-6 max-w-md">Our AI Tutor is ready to help you with Hamlet, Phonetics, or any other topic in your syllabus.</p>
                    <Button variant="secondary" onClick={() => setPage("tutor")} className="bg-white text-teal-700 hover:bg-teal-50">
                      Start Learning
                    </Button>
                  </div>
                  <BrainCircuit className="absolute -right-10 -bottom-10 w-64 h-64 text-white/10 group-hover:scale-110 transition-transform duration-700" />
                </Card>

                <Card className="flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-bold text-slate-800">Quick Stats</h3>
                      <Badge variant="Normal">Live</Badge>
                    </div>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-slate-500">Materials</span>
                        <span className="font-bold text-slate-700">{materials.length}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-slate-500">Active Notices</span>
                        <span className="font-bold text-slate-700">{notices.length}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-slate-500">Quizzes Attempted</span>
                        <span className="font-bold text-teal-600">{quizzesAttempted}</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-6 pt-6 border-t border-slate-50">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Next Class</p>
                    <p className="font-bold text-slate-700">English Literature • 10:30 AM</p>
                  </div>
                </Card>

                {/* Timetable Preview */}
                <Card className="md:col-span-2 overflow-hidden p-0">
                  <div className="p-6 border-b border-slate-50">
                    <h3 className="font-bold text-slate-800">Weekly Schedule</h3>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50">
                          <th className="px-6 py-3 text-xs font-bold text-slate-400 uppercase tracking-wider">Time</th>
                          <th className="px-6 py-3 text-xs font-bold text-slate-400 uppercase tracking-wider">Mon</th>
                          <th className="px-6 py-3 text-xs font-bold text-slate-400 uppercase tracking-wider">Tue</th>
                          <th className="px-6 py-3 text-xs font-bold text-slate-400 uppercase tracking-wider">Wed</th>
                          <th className="px-6 py-3 text-xs font-bold text-slate-400 uppercase tracking-wider">Thu</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {TIMETABLE.map((row, i) => (
                          <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                            <td className="px-6 py-4 text-sm font-bold text-slate-700">{row.time}</td>
                            <td className="px-6 py-4 text-sm text-slate-600">{row.mon}</td>
                            <td className="px-6 py-4 text-sm text-slate-600">{row.tue}</td>
                            <td className="px-6 py-4 text-sm text-slate-600">{row.wed}</td>
                            <td className="px-6 py-4 text-sm text-slate-600">{row.thu}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </Card>

                {/* Notices Preview */}
                <Card className="flex flex-col">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="font-bold text-slate-800">Latest Notices</h3>
                    <button onClick={() => setPage("notices")} className="text-xs font-bold text-teal-600 hover:underline">View All</button>
                  </div>
                  <div className="space-y-4 flex-1">
                    {notices.slice(0, 3).map((notice) => (
                      <div key={notice.id} className="flex gap-3 group">
                        <div className={cn(
                          "w-1 h-10 rounded-full shrink-0",
                          notice.priority === "High" ? "bg-rose-500" : notice.priority === "Medium" ? "bg-amber-500" : "bg-teal-500"
                        )} />
                        <div>
                          <p className="text-sm font-bold text-slate-700 group-hover:text-teal-600 transition-colors">{notice.title}</p>
                          <p className="text-xs text-slate-500 line-clamp-1">{notice.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            </motion.div>
          )}

          {page === "tutor" && (
            <motion.div 
              key="tutor"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="h-[calc(100vh-4rem)] md:h-[calc(100vh-8rem)] flex flex-col"
            >
              <div className="mb-6">
                <h2 className="text-3xl font-bold text-slate-800 flex items-center gap-3">
                  <BrainCircuit className="w-8 h-8 text-teal-600" />
                  AI Tutor
                </h2>
                <p className="text-slate-500">Ask me anything about your English syllabus.</p>
              </div>

              <Card className="flex-1 flex flex-col p-0 overflow-hidden">
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                  {chatHistory.length === 0 && (
                    <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
                      <div className="w-16 h-16 bg-teal-50 rounded-full flex items-center justify-center">
                        <Sparkles className="w-8 h-8 text-teal-600" />
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-800">How can I help you today?</h3>
                        <p className="text-sm text-slate-500 max-w-xs">Try asking about "Hamlet's soliloquy" or "The history of English language".</p>
                      </div>
                    </div>
                  )}
                  {chatHistory.map((msg, i) => (
                    <div key={i} className={cn("flex", msg.role === "user" ? "justify-end" : "justify-start")}>
                      <div className={cn(
                        "max-w-[85%] p-4 rounded-2xl shadow-sm",
                        msg.role === "user" 
                          ? "bg-teal-600 text-white rounded-tr-none" 
                          : "bg-slate-50 text-slate-800 border border-slate-100 rounded-tl-none"
                      )}>
                        <div className="text-xs font-bold uppercase tracking-widest mb-1 opacity-50">
                          {msg.role === "user" ? "You" : "EduBridge AI"}
                        </div>
                        <div className="prose prose-sm prose-slate max-w-none dark:prose-invert">
                          <ReactMarkdown>{msg.content}</ReactMarkdown>
                        </div>
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-slate-50 p-4 rounded-2xl rounded-tl-none border border-slate-100 shadow-sm">
                        <div className="flex gap-1">
                          <div className="w-2 h-2 bg-teal-400 rounded-full animate-bounce" />
                          <div className="w-2 h-2 bg-teal-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                          <div className="w-2 h-2 bg-teal-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </div>

                <div className="p-4 border-t border-slate-100 bg-white">
                  <div className="flex gap-2">
                    <input 
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendAIChat()}
                      placeholder="Type your question here..."
                      className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 transition-all"
                    />
                    <Button onClick={handleSendAIChat} disabled={isLoading || !input.trim()} className="shrink-0">
                      <Send className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
              </Card>
            </motion.div>
          )}

          {page === "materials" && (
            <motion.div 
              key="materials"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h2 className="text-3xl font-bold text-slate-800">Study Materials</h2>
                  <p className="text-slate-500">Browse and download resources for your courses.</p>
                </div>
              </div>

              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search materials by name or category..."
                  className="w-full bg-white border border-slate-200 rounded-2xl pl-12 pr-4 py-4 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 transition-all"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {(["qual", "f1", "f2"] as const).map((cat) => (
                  <div key={cat} className="space-y-4">
                    <div className="flex items-center justify-between px-2">
                      <h3 className="font-bold text-slate-800 flex items-center gap-2">
                        <div className={cn(
                          "w-2 h-2 rounded-full",
                          cat === "qual" ? "bg-teal-500" : cat === "f1" ? "bg-indigo-500" : "bg-rose-500"
                        )} />
                        {cat === "qual" ? "First Year (Qual)" : cat === "f1" ? "Second Year (F1)" : "Third Year (F2)"}
                      </h3>
                      {(role === "admin" || role === "teacher") && (
                        <label className="cursor-pointer bg-slate-100 hover:bg-slate-200 p-1.5 rounded-lg transition-colors">
                          <Plus className="w-4 h-4 text-slate-600" />
                          <input 
                            type="file" 
                            className="hidden" 
                            accept=".pdf" 
                            onChange={(e) => handleUpload(e, cat)}
                          />
                        </label>
                      )}
                    </div>
                    {filteredMaterials.filter(m => m.category === cat).length > 0 ? (
                      filteredMaterials.filter(m => m.category === cat).map(material => (
                        <Card key={material.id} className="p-4 group hover:border-teal-200">
                          <div className="flex items-start gap-4">
                            <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center group-hover:bg-teal-50 transition-colors">
                              <FileText className="w-6 h-6 text-slate-400 group-hover:text-teal-600 transition-colors" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-bold text-slate-800 text-sm truncate">{material.name}</p>
                              <p className="text-xs text-slate-400 mt-1">Uploaded: {material.uploadDate}</p>
                            </div>
                          </div>
                          <div className="mt-4 flex items-center justify-between">
                            <Badge variant="Normal">PDF</Badge>
                            <div className="flex items-center gap-2">
                              {role === "admin" && (
                                <button 
                                  onClick={() => handleDeleteMaterial(material.id)}
                                  className="text-xs font-bold text-rose-500 hover:underline flex items-center gap-1"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  Delete
                                </button>
                              )}
                              <button className="text-xs font-bold text-teal-600 hover:underline">Download</button>
                            </div>
                          </div>
                        </Card>
                      ))
                    ) : (
                      <div className="p-8 border-2 border-dashed border-slate-100 rounded-2xl text-center">
                        <p className="text-xs text-slate-400">No materials found</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {page === "quiz" && (
            <motion.div 
              key="quiz"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div>
                <h2 className="text-3xl font-bold text-slate-800">AI Quiz Generator</h2>
                <p className="text-slate-500">Test your knowledge with custom generated assessments.</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <Card className="lg:col-span-1 h-fit">
                  <h3 className="font-bold text-slate-800 mb-6">Quiz Settings</h3>
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">Source</label>
                      <div className="grid grid-cols-2 gap-2">
                        <button 
                          onClick={() => setQuizSource("ai")}
                          className={cn(
                            "py-2 rounded-xl text-xs font-bold border transition-all",
                            quizSource === "ai" ? "bg-teal-50 border-teal-200 text-teal-700" : "bg-white border-slate-200 text-slate-500"
                          )}
                        >
                          AI Knowledge
                        </button>
                        <button 
                          onClick={() => setQuizSource("material")}
                          className={cn(
                            "py-2 rounded-xl text-xs font-bold border transition-all",
                            quizSource === "material" ? "bg-teal-50 border-teal-200 text-teal-700" : "bg-white border-slate-200 text-slate-500"
                          )}
                        >
                          Study Material
                        </button>
                      </div>
                    </div>

                    {quizSource === "material" && (
                      <>
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-2">Year / Category</label>
                          <select 
                            value={quizYear}
                            onChange={(e) => {
                              setQuizYear(e.target.value as any);
                              setQuizMaterialId("none");
                            }}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                          >
                            <option value="all">All Materials</option>
                            <option value="qual">First Year (Qual)</option>
                            <option value="f1">Second Year (F1)</option>
                            <option value="f2">Third Year (F2)</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-2">Specific Material (Optional)</label>
                          <select 
                            value={quizMaterialId}
                            onChange={(e) => setQuizMaterialId(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                          >
                            <option value="none">Select a file...</option>
                            {materials
                              .filter(m => quizYear === "all" || m.category === quizYear)
                              .map(m => (
                                <option key={m.id} value={m.id}>{m.name}</option>
                              ))
                            }
                          </select>
                        </div>
                      </>
                    )}

                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">Topic / Keyword</label>
                      <input 
                        id="quiz-topic"
                        placeholder="e.g. Shakespearean Tragedy"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">Questions</label>
                      <select id="quiz-count" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500">
                        <option value="5">5 Questions</option>
                        <option value="10">10 Questions</option>
                        <option value="15">15 Questions</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">Type</label>
                      <select id="quiz-type" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500">
                        <option value="MCQ">Multiple Choice</option>
                        <option value="TF">True / False</option>
                        <option value="Short">Short Statement</option>
                        <option value="Long">Long Statement</option>
                        <option value="Mixed">Mixed</option>
                      </select>
                    </div>
                    <Button 
                      onClick={() => {
                        const topic = (document.getElementById('quiz-topic') as HTMLInputElement).value;
                        const count = parseInt((document.getElementById('quiz-count') as HTMLSelectElement).value);
                        const type = (document.getElementById('quiz-type') as HTMLSelectElement).value;
                        handleGenerateQuiz(topic, count, type);
                      }}
                      disabled={isLoading}
                      className="w-full py-4"
                    >
                      {isLoading ? "Generating..." : "Generate Quiz"}
                    </Button>
                  </div>
                </Card>

                <Card className="lg:col-span-2 min-h-[400px] flex flex-col">
                  <div className="flex items-center justify-between mb-6 pb-6 border-b border-slate-50">
                    <h3 className="font-bold text-slate-800">Quiz Result</h3>
                    {(quizResult || quizQuestions.length > 0) && <Button variant="ghost" className="text-xs" onClick={() => { setQuizResult(""); setQuizQuestions([]); setQuizScore(null); }}>Clear</Button>}
                  </div>
                  <div className="flex-1">
                    {isLoading ? (
                      <div className="flex flex-col items-center justify-center h-full space-y-4">
                        <div className="w-12 h-12 border-4 border-teal-100 border-t-teal-600 rounded-full animate-spin" />
                        <p className="text-slate-500 font-medium">Creating your quiz...</p>
                      </div>
                    ) : quizQuestions.length > 0 ? (
                      <div className="space-y-8">
                        {quizScore === null ? (
                          <>
                            <div className="flex items-center justify-between mb-4">
                              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Question {currentQuizIndex + 1} of {quizQuestions.length}</span>
                              <Badge variant="Normal">{quizQuestions[currentQuizIndex].type}</Badge>
                            </div>
                            <h4 className="text-lg font-bold text-slate-800 mb-6">{quizQuestions[currentQuizIndex].question}</h4>
                            
                            <div className="space-y-3">
                              {quizQuestions[currentQuizIndex].type === "MCQ" ? (
                                quizQuestions[currentQuizIndex].options.map((opt: string, idx: number) => {
                                  const letter = String.fromCharCode(65 + idx);
                                  return (
                                    <button 
                                      key={idx}
                                      onClick={() => setQuizAnswers(prev => ({ ...prev, [quizQuestions[currentQuizIndex].id]: letter }))}
                                      className={cn(
                                        "w-full text-left p-4 rounded-xl border transition-all flex items-center gap-3",
                                        quizAnswers[quizQuestions[currentQuizIndex].id] === letter 
                                          ? "bg-teal-50 border-teal-500 text-teal-700" 
                                          : "bg-white border-slate-100 hover:border-teal-200 text-slate-600"
                                      )}
                                    >
                                      <div className={cn(
                                        "w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm",
                                        quizAnswers[quizQuestions[currentQuizIndex].id] === letter ? "bg-teal-600 text-white" : "bg-slate-100 text-slate-500"
                                      )}>
                                        {letter}
                                      </div>
                                      {opt}
                                    </button>
                                  );
                                })
                              ) : (
                                ["True", "False"].map((opt) => (
                                  <button 
                                    key={opt}
                                    onClick={() => setQuizAnswers(prev => ({ ...prev, [quizQuestions[currentQuizIndex].id]: opt }))}
                                    className={cn(
                                      "w-full text-left p-4 rounded-xl border transition-all flex items-center gap-3",
                                      quizAnswers[quizQuestions[currentQuizIndex].id] === opt 
                                        ? "bg-teal-50 border-teal-500 text-teal-700" 
                                        : "bg-white border-slate-100 hover:border-teal-200 text-slate-600"
                                    )}
                                  >
                                    <div className={cn(
                                      "w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm",
                                      quizAnswers[quizQuestions[currentQuizIndex].id] === opt ? "bg-teal-600 text-white" : "bg-slate-100 text-slate-500"
                                    )}>
                                      {opt[0]}
                                    </div>
                                    {opt}
                                  </button>
                                ))
                              )}
                            </div>

                            <div className="flex items-center justify-between mt-8 pt-6 border-t border-slate-50">
                              <Button 
                                variant="ghost" 
                                disabled={currentQuizIndex === 0}
                                onClick={() => setCurrentQuizIndex(prev => prev - 1)}
                              >
                                Previous
                              </Button>
                              {currentQuizIndex === quizQuestions.length - 1 ? (
                                <Button onClick={handleQuizSubmit} disabled={Object.keys(quizAnswers).length < quizQuestions.length}>
                                  Submit Quiz
                                </Button>
                              ) : (
                                <Button onClick={() => setCurrentQuizIndex(prev => prev + 1)}>
                                  Next Question
                                </Button>
                              )}
                            </div>
                          </>
                        ) : (
                          <div className="text-center py-12 space-y-6">
                            <div className="w-24 h-24 bg-teal-50 rounded-full flex items-center justify-center mx-auto">
                              <CheckCircle2 className="w-12 h-12 text-teal-600" />
                            </div>
                            <div>
                              <h3 className="text-2xl font-bold text-slate-800">Quiz Completed!</h3>
                              <p className="text-slate-500">You scored {quizScore} out of {quizQuestions.length}</p>
                            </div>
                            <div className="text-4xl font-black text-teal-600">
                              {Math.round((quizScore / quizQuestions.length) * 100)}%
                            </div>
                            <Button onClick={() => { setQuizQuestions([]); setQuizScore(null); }}>
                              Try Another Quiz
                            </Button>
                          </div>
                        )}
                      </div>
                    ) : quizResult ? (
                      <div className="prose prose-slate max-w-none">
                        <ReactMarkdown>{quizResult}</ReactMarkdown>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-center space-y-4 opacity-40">
                        <Puzzle className="w-16 h-16 text-slate-300" />
                        <p className="text-slate-500">Your generated quiz will appear here.</p>
                      </div>
                    )}
                  </div>
                </Card>
              </div>
            </motion.div>
          )}

          {page === "notices" && (
            <motion.div 
              key="notices"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex flex-col md:items-center justify-center text-center space-y-2">
                <h2 className="text-3xl font-bold text-slate-800">Announcements</h2>
                <p className="text-slate-500">Stay updated with the latest news from the department.</p>
              </div>

              <div className="max-w-3xl mx-auto space-y-4">
                {notices.map((notice) => (
                  <Card key={notice.id} className={cn(
                    "relative overflow-hidden",
                    notice.priority === "High" ? "border-l-4 border-l-rose-500" : notice.priority === "Medium" ? "border-l-4 border-l-amber-500" : "border-l-4 border-l-teal-500"
                  )}>
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "w-10 h-10 rounded-xl flex items-center justify-center",
                          notice.priority === "High" ? "bg-rose-50" : notice.priority === "Medium" ? "bg-amber-50" : "bg-teal-50"
                        )}>
                          <Bell className={cn(
                            "w-5 h-5",
                            notice.priority === "High" ? "text-rose-600" : notice.priority === "Medium" ? "text-amber-600" : "text-teal-600"
                          )} />
                        </div>
                        <div>
                          <h3 className="font-bold text-slate-800">{notice.title}</h3>
                          <p className="text-xs text-slate-400">{notice.date}</p>
                        </div>
                      </div>
                      <Badge variant={notice.priority}>{notice.priority}</Badge>
                    </div>
                    <p className="text-slate-600 leading-relaxed">{notice.text}</p>
                    {role === "admin" && (
                      <div className="mt-6 pt-6 border-t border-slate-50 flex justify-end">
                        <Button 
                          variant="ghost" 
                          className="text-rose-500 hover:bg-rose-50 hover:text-rose-600"
                          onClick={() => handleDeleteNotice(notice.id)}
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete Notice
                        </Button>
                      </div>
                    )}
                  </Card>
                ))}
                {role === "admin" && (
                  <div className="space-y-4">
                    {showNoticeForm ? (
                      <Card className="border-2 border-teal-500 bg-teal-50/30">
                        <h3 className="font-bold text-slate-800 mb-4">Post New Announcement</h3>
                        <div className="space-y-4">
                          <input 
                            value={newNoticeTitle}
                            onChange={(e) => setNewNoticeTitle(e.target.value)}
                            placeholder="Notice Title"
                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                          />
                          <textarea 
                            value={newNoticeText}
                            onChange={(e) => setNewNoticeText(e.target.value)}
                            placeholder="Announcement details..."
                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 h-32"
                          />
                          <div className="flex items-center gap-4">
                            <select 
                              value={newNoticePriority}
                              onChange={(e) => setNewNoticePriority(e.target.value as any)}
                              className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                            >
                              <option value="Normal">Normal Priority</option>
                              <option value="Medium">Medium Priority</option>
                              <option value="High">High Priority</option>
                            </select>
                            <div className="flex-1" />
                            <Button variant="ghost" onClick={() => setShowNoticeForm(false)}>Cancel</Button>
                            <Button 
                              onClick={() => {
                                if (newNoticeTitle && newNoticeText) {
                                  handleAddNotice(newNoticeTitle, newNoticeText, newNoticePriority);
                                  setNewNoticeTitle("");
                                  setNewNoticeText("");
                                  setShowNoticeForm(false);
                                }
                              }}
                              disabled={!newNoticeTitle || !newNoticeText}
                            >
                              Post Notice
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ) : (
                      <button 
                        onClick={() => setShowNoticeForm(true)}
                        className="w-full p-6 rounded-2xl border-2 border-dashed border-slate-200 hover:border-teal-500 hover:bg-teal-50 transition-all flex items-center justify-center gap-2 text-slate-400 hover:text-teal-600 font-bold group"
                      >
                        <Plus className="w-5 h-5 group-hover:scale-110 transition-transform" />
                        Post New Announcement
                      </button>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {page === "manage-timetable" && role === "admin" && (
            <motion.div 
              key="manage-timetable"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold text-slate-800">Manage Timetable</h2>
                  <p className="text-slate-500">Update the weekly schedule for the department.</p>
                </div>
                <div className="flex gap-2">
                  <input 
                    type="file" 
                    id="timetable-pic-upload" 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleTimetableImageUpload} 
                  />
                  <Button variant="secondary" onClick={() => document.getElementById('timetable-pic-upload')?.click()} className="flex items-center gap-2">
                    <Camera className="w-4 h-4" />
                    Upload Pic
                  </Button>
                  <Button onClick={handleAddTimetableRow} className="flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Add Row
                  </Button>
                </div>
              </div>

              <Card>
                {timetableImage && (
                  <div className="mb-8 relative group">
                    <img src={timetableImage} alt="Timetable" className="w-full rounded-xl border border-slate-200" referrerPolicy="no-referrer" />
                    <button 
                      onClick={() => setTimetableImage(null)}
                      className="absolute top-2 right-2 bg-rose-500 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold tracking-widest">
                      <tr>
                        <th className="px-6 py-4">Time</th>
                        <th className="px-6 py-4">Mon</th>
                        <th className="px-6 py-4">Tue</th>
                        <th className="px-6 py-4">Wed</th>
                        <th className="px-6 py-4">Thu</th>
                        <th className="px-6 py-4">Fri</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {timetable.map((row, idx) => (
                        <tr key={idx}>
                          <td className="px-6 py-4 font-medium text-slate-800">
                            <input 
                              type="text"
                              value={row.time}
                              onChange={(e) => {
                                const newTimetable = [...timetable];
                                newTimetable[idx].time = e.target.value;
                                setTimetable(newTimetable);
                              }}
                              className="w-full bg-transparent border-none focus:ring-1 focus:ring-teal-500 rounded p-1"
                            />
                          </td>
                          {['mon', 'tue', 'wed', 'thu', 'fri'].map((day) => (
                            <td key={day} className="px-6 py-4">
                              <input 
                                type="text"
                                value={(row as any)[day]}
                                onChange={(e) => {
                                  const newTimetable = [...timetable];
                                  (newTimetable[idx] as any)[day] = e.target.value;
                                  setTimetable(newTimetable);
                                }}
                                className="w-full bg-transparent border-none focus:ring-1 focus:ring-teal-500 rounded p-1"
                              />
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="p-6 bg-slate-50 flex justify-end">
                  <Button onClick={() => alert("Timetable saved successfully!")}>Save Changes</Button>
                </div>
              </Card>
            </motion.div>
          )}

          {page === "chat" && (
            <motion.div 
              key="chat"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="h-[calc(100vh-120px)] flex flex-col"
            >
              <div className="mb-6">
                <h2 className="text-3xl font-bold text-slate-800">Department Group Chat</h2>
                <p className="text-slate-500">Real-time discussion and file sharing (up to 50MB).</p>
              </div>

              <Card className="flex-1 flex flex-col p-0 overflow-hidden">
                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  {messages.map((msg) => (
                    <div 
                      key={msg.id} 
                      className={cn(
                        "flex flex-col max-w-[80%]",
                        msg.senderId === currentUser?.id ? "ml-auto items-end" : "mr-auto items-start"
                      )}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{msg.senderName}</span>
                        <Badge variant={msg.senderRole === "admin" ? "High" : msg.senderRole === "teacher" ? "Medium" : "Normal"}>
                          {msg.senderRole}
                        </Badge>
                      </div>
                      <div className={cn(
                        "p-4 rounded-2xl shadow-sm relative group",
                        msg.senderId === currentUser?.id ? "bg-teal-600 text-white rounded-tr-none" : "bg-slate-100 text-slate-800 rounded-tl-none"
                      )}>
                        {msg.content && <p className="text-sm whitespace-pre-wrap">{msg.content}</p>}
                        
                        {msg.fileUrl && (
                          <div className={cn(
                            "mt-2 p-3 rounded-xl flex items-center gap-3 border",
                            msg.senderId === currentUser?.id ? "bg-white/10 border-white/20" : "bg-white border-slate-200"
                          )}>
                            <div className="w-10 h-10 bg-teal-500/20 rounded-lg flex items-center justify-center">
                              <FileText className="w-5 h-5 text-teal-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-bold truncate">{msg.fileName}</p>
                              <p className="text-[10px] opacity-60">{(msg.fileSize / 1024 / 1024).toFixed(2)} MB</p>
                            </div>
                            <a 
                              href={msg.fileUrl} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="p-2 hover:bg-black/5 rounded-lg transition-colors"
                            >
                              <Upload className="w-4 h-4 rotate-180" />
                            </a>
                          </div>
                        )}

                        {(role === "admin" || msg.senderId === currentUser?.id) && (
                          <button 
                            onClick={() => handleDeleteMessage(msg.id)}
                            className="absolute -top-2 -right-2 bg-rose-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                      <span className="text-[9px] text-slate-400 mt-1">
                        {msg.timestamp?.toDate ? msg.timestamp.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Sending...'}
                      </span>
                    </div>
                  ))}
                  <div ref={chatEndRef} />
                </div>

                {uploadProgress !== null && (
                  <div className="px-6 py-2 bg-teal-50 border-t border-teal-100">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold text-teal-600 uppercase">Uploading File...</span>
                      <span className="text-[10px] font-bold text-teal-600">{Math.round(uploadProgress)}%</span>
                    </div>
                    <div className="w-full h-1 bg-teal-200 rounded-full overflow-hidden">
                      <div className="h-full bg-teal-600 transition-all duration-300" style={{ width: `${uploadProgress}%` }} />
                    </div>
                  </div>
                )}

                <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center gap-3">
                  <input 
                    type="file" 
                    id="chat-file" 
                    className="hidden" 
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleSendMessage("", file);
                    }}
                  />
                  <button 
                    onClick={() => document.getElementById('chat-file')?.click()}
                    className="p-3 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-teal-600 hover:border-teal-200 transition-all shadow-sm"
                  >
                    <Upload className="w-5 h-5" />
                  </button>
                  <div className="flex-1 relative">
                    <textarea 
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage(input);
                        }
                      }}
                      placeholder="Type a message..."
                      className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none h-[46px]"
                    />
                  </div>
                  <button 
                    onClick={() => handleSendMessage(input)}
                    disabled={!input.trim()}
                    className="p-3 bg-teal-600 text-white rounded-xl hover:bg-teal-700 disabled:opacity-50 transition-all shadow-lg shadow-teal-100"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </Card>
            </motion.div>
          )}

          {page === "photos" && (
            <motion.div 
              key="photos"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold text-slate-800">Department Gallery</h2>
                  <p className="text-slate-500">Capturing moments from our activities and events.</p>
                </div>
                {role === "admin" && (
                  <div>
                    <input 
                      type="file" 
                      id="photo-upload" 
                      className="hidden" 
                      accept="image/*" 
                      onChange={handlePhotoUpload} 
                    />
                    <Button onClick={() => document.getElementById('photo-upload')?.click()} className="flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      Upload Photo
                    </Button>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {photos.map((photo) => (
                  <Card key={photo.id} className="p-0 overflow-hidden group">
                    <div className="aspect-video relative">
                      <img src={photo.url} alt={photo.caption} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      {role === "admin" && (
                        <button 
                          onClick={() => handleDeletePhoto(photo.id)}
                          className="absolute top-2 right-2 bg-rose-500 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    <div className="p-4">
                      <p className="font-bold text-slate-800">{photo.caption}</p>
                      <p className="text-xs text-slate-400 mt-1">{photo.date}</p>
                    </div>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}

          {page === "dictionary" && (
            <motion.div 
              key="dictionary"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="text-center max-w-2xl mx-auto">
                <h2 className="text-3xl font-bold text-slate-800 flex items-center justify-center gap-3">
                  <Languages className="w-8 h-8 text-teal-600" />
                  English ↔ Burmese Dictionary
                </h2>
                <p className="text-slate-500 mt-2">Translate words and phrases between English and Burmese with AI assistance.</p>
              </div>

              <div className="max-w-3xl mx-auto space-y-6">
                <Card className="p-8">
                  <div className="flex flex-col md:flex-row gap-4 mb-6">
                    <div className="flex-1">
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Translation Direction</label>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => setDictionaryDirection("en-my")}
                          className={cn(
                            "flex-1 py-3 rounded-xl text-sm font-bold border transition-all",
                            dictionaryDirection === "en-my" ? "bg-teal-50 border-teal-500 text-teal-700" : "bg-white border-slate-200 text-slate-500"
                          )}
                        >
                          English to Burmese
                        </button>
                        <button 
                          onClick={() => setDictionaryDirection("my-en")}
                          className={cn(
                            "flex-1 py-3 rounded-xl text-sm font-bold border transition-all",
                            dictionaryDirection === "my-en" ? "bg-teal-50 border-teal-500 text-teal-700" : "bg-white border-slate-200 text-slate-500"
                          )}
                        >
                          Burmese to English
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">
                        {dictionaryDirection === "en-my" ? "Enter English Text" : "Enter Burmese Text"}
                      </label>
                      <div className="relative">
                        <textarea 
                          value={dictionaryInput}
                          onChange={(e) => setDictionaryInput(e.target.value)}
                          placeholder={dictionaryDirection === "en-my" ? "e.g. Literature" : "e.g. စာပေ"}
                          className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 text-lg focus:outline-none focus:ring-2 focus:ring-teal-500 transition-all h-32 resize-none"
                        />
                      </div>
                    </div>

                    <Button 
                      onClick={handleTranslate} 
                      disabled={isLoading || !dictionaryInput.trim()} 
                      className="w-full py-4 text-lg flex items-center justify-center gap-2"
                    >
                      {isLoading ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          Translating...
                        </>
                      ) : (
                        <>
                          <Languages className="w-5 h-5" />
                          Translate Now
                        </>
                      )}
                    </Button>
                  </div>
                </Card>

                {dictionaryResult && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <Card className="bg-teal-50 border-teal-100">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-bold text-teal-800">Translation Result</h3>
                        <Button variant="ghost" className="text-xs text-teal-600" onClick={() => setDictionaryResult("")}>Clear</Button>
                      </div>
                      <div className="prose prose-teal max-w-none">
                        <ReactMarkdown>{dictionaryResult}</ReactMarkdown>
                      </div>
                    </Card>
                  </motion.div>
                )}
              </div>
            </motion.div>
          )}

          {page === "map" && (
            <motion.div 
              key="map"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <CampusMap />
            </motion.div>
          )}

          {page === "notes" && role === "teacher" && (
            <motion.div 
              key="notes"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div>
                <h2 className="text-3xl font-bold text-slate-800">Notes Generator</h2>
                <p className="text-slate-500">Create comprehensive study notes for your students instantly.</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <Card className="lg:col-span-1 h-fit">
                  <h3 className="font-bold text-slate-800 mb-6">Notes Configuration</h3>
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">Source</label>
                      <div className="grid grid-cols-2 gap-2">
                        <button 
                          onClick={() => setNotesSource("ai")}
                          className={cn(
                            "py-2 rounded-xl text-xs font-bold border transition-all",
                            notesSource === "ai" ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-white border-slate-200 text-slate-500"
                          )}
                        >
                          AI Knowledge
                        </button>
                        <button 
                          onClick={() => setNotesSource("material")}
                          className={cn(
                            "py-2 rounded-xl text-xs font-bold border transition-all",
                            notesSource === "material" ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-white border-slate-200 text-slate-500"
                          )}
                        >
                          Study Material
                        </button>
                      </div>
                    </div>

                    {notesSource === "material" && (
                      <>
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-2">Year / Category</label>
                          <select 
                            value={notesYear}
                            onChange={(e) => {
                              setNotesYear(e.target.value as any);
                              setNotesMaterialId("none");
                            }}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          >
                            <option value="all">All Materials</option>
                            <option value="qual">First Year (Qual)</option>
                            <option value="f1">Second Year (F1)</option>
                            <option value="f2">Third Year (F2)</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-2">Specific Material (Optional)</label>
                          <select 
                            value={notesMaterialId}
                            onChange={(e) => setNotesMaterialId(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          >
                            <option value="none">Select a file...</option>
                            {materials
                              .filter(m => notesYear === "all" || m.category === notesYear)
                              .map(m => (
                                <option key={m.id} value={m.id}>{m.name}</option>
                              ))
                            }
                          </select>
                        </div>
                      </>
                    )}

                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">Topic / Subject</label>
                      <input 
                        id="notes-topic"
                        placeholder="e.g. Victorian Poetry"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">Format</label>
                      <select id="notes-format" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="Summary Notes">Summary Notes</option>
                        <option value="Detailed Lecture Notes">Detailed Lecture Notes</option>
                        <option value="Key Points & Bulletins">Key Points & Bulletins</option>
                        <option value="Q&A Format">Q&A Format</option>
                      </select>
                    </div>
                    <Button 
                      onClick={() => {
                        const topic = (document.getElementById('notes-topic') as HTMLInputElement).value;
                        const format = (document.getElementById('notes-format') as HTMLSelectElement).value;
                        handleGenerateNotes(topic, format);
                      }}
                      disabled={isLoading}
                      className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 shadow-indigo-100"
                    >
                      {isLoading ? "Generating..." : "Generate Notes"}
                    </Button>
                  </div>
                </Card>

                <Card className="lg:col-span-2 min-h-[500px] flex flex-col">
                  <div className="flex items-center justify-between mb-6 pb-6 border-b border-slate-50">
                    <h3 className="font-bold text-slate-800">Generated Content</h3>
                    {notesResult && (
                      <div className="flex gap-2">
                        <Button variant="ghost" className="text-xs" onClick={() => setNotesResult("")}>Clear</Button>
                        <Button variant="secondary" className="text-xs" onClick={() => {
                          navigator.clipboard.writeText(notesResult);
                          alert("Notes copied to clipboard!");
                        }}>Copy Text</Button>
                        <Button variant="secondary" className="text-xs flex items-center gap-1" onClick={handleDownloadPDF}>
                          <FileText className="w-3 h-3" />
                          PDF
                        </Button>
                        <Button variant="secondary" className="text-xs flex items-center gap-1" onClick={handleDownloadDOCX}>
                          <FileText className="w-3 h-3" />
                          DOCX
                        </Button>
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    {isLoading ? (
                      <div className="flex flex-col items-center justify-center h-full space-y-4">
                        <div className="w-12 h-12 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin" />
                        <p className="text-slate-500 font-medium">Crafting your notes...</p>
                      </div>
                    ) : notesResult ? (
                      <div className="prose prose-indigo max-w-none">
                        <ReactMarkdown>{notesResult}</ReactMarkdown>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-center space-y-4 opacity-40">
                        <FileText className="w-16 h-16 text-slate-300" />
                        <p className="text-slate-500">Your generated notes will appear here.</p>
                      </div>
                    )}
                  </div>
                </Card>
              </div>
            </motion.div>
          )}

          {page === "manage-users" && role === "admin" && (
            <motion.div 
              key="manage-users"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold text-slate-800">User Management</h2>
                  <p className="text-slate-500">Allot usernames and passwords to students and teachers.</p>
                </div>
                <Button onClick={() => {
                  const name = prompt("Enter Full Name:");
                  const uname = prompt("Enter Username:");
                  const pword = prompt("Enter Password:");
                  const urole = prompt("Enter Role (student/teacher/admin):") as any;
                  if (name && uname && pword && urole) {
                    setUsers(prev => [...prev, { id: Math.random().toString(36).substr(2, 9), fullName: name, username: uname, password: pword, role: urole }]);
                  }
                }} className="flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Add User
                </Button>
              </div>

              <Card className="p-0 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold tracking-widest">
                      <tr>
                        <th className="px-6 py-4">Full Name</th>
                        <th className="px-6 py-4">Username</th>
                        <th className="px-6 py-4">Password</th>
                        <th className="px-6 py-4">Role</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {users.map((u) => (
                        <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 font-bold text-slate-800">{u.fullName}</td>
                          <td className="px-6 py-4 text-slate-600">{u.username}</td>
                          <td className="px-6 py-4 text-slate-600 font-mono">{u.password}</td>
                          <td className="px-6 py-4">
                            <Badge variant={u.role === "admin" ? "High" : u.role === "teacher" ? "Medium" : "Normal"}>
                              {u.role}
                            </Badge>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <button 
                              onClick={() => setUsers(prev => prev.filter(user => user.id !== u.id))}
                              className="text-rose-500 hover:text-rose-700 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
