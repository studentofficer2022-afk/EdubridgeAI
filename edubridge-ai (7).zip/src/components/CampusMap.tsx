import React from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import { MapPin, Navigation, Info } from "lucide-react";
import { motion } from "motion/react";

// Fix for default marker icon in Leaflet + React
// @ts-ignore
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

const CAMPUS_CENTER: [number, number] = [16.8661, 96.1951]; // Fictional Yangon University location

const LOCATIONS = [
  { id: 1, name: "English Department", pos: [16.8661, 96.1951] as [number, number], desc: "Main building for English Literature and Linguistics." },
  { id: 2, name: "Main Library", pos: [16.8675, 96.1965] as [number, number], desc: "Central library with extensive English collection." },
  { id: 3, name: "Student Union", pos: [16.8650, 96.1940] as [number, number], desc: "Hub for student activities and DSA initiatives." },
  { id: 4, name: "Department Cafeteria", pos: [16.8645, 96.1960] as [number, number], desc: "Popular spot for literary discussions over coffee." },
];

export default function CampusMap() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 flex items-center gap-3">
            <MapPin className="w-8 h-8 text-teal-600" />
            Campus Map
          </h2>
          <p className="text-slate-500">Find your way around the English Department and campus.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 h-[600px] rounded-3xl overflow-hidden border border-slate-200 shadow-sm z-10">
          <MapContainer 
            center={CAMPUS_CENTER} 
            zoom={16} 
            style={{ height: "100%", width: "100%" }}
            scrollWheelZoom={false}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {LOCATIONS.map((loc) => (
              <Marker key={loc.id} position={loc.pos}>
                <Popup>
                  <div className="p-1">
                    <h4 className="font-bold text-slate-800">{loc.name}</h4>
                    <p className="text-xs text-slate-500 mt-1">{loc.desc}</p>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>

        <div className="space-y-4">
          <h3 className="font-bold text-slate-800 flex items-center gap-2">
            <Navigation className="w-4 h-4 text-teal-600" />
            Key Locations
          </h3>
          <div className="space-y-3">
            {LOCATIONS.map((loc) => (
              <motion.div 
                key={loc.id}
                whileHover={{ x: 4 }}
                className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm hover:border-teal-200 transition-all cursor-pointer"
              >
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-teal-50 rounded-lg flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4 text-teal-600" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-700">{loc.name}</p>
                    <p className="text-[10px] text-slate-400 mt-1 line-clamp-2">{loc.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="p-4 bg-teal-50 rounded-2xl border border-teal-100 mt-4">
            <div className="flex items-center gap-2 mb-2">
              <Info className="w-4 h-4 text-teal-600" />
              <span className="text-xs font-bold text-teal-800 uppercase tracking-wider">Note</span>
            </div>
            <p className="text-[11px] text-teal-700 leading-relaxed">
              This is a real-time interactive map. Use your mouse or touch to navigate and click markers for more details.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
